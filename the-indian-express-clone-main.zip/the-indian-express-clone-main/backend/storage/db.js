const mongoose = require("mongoose");

module.exports = mongoose.connect(
  "mongodb+srv://DBuser:54fhXTVTQJxpLPxP@unit5cluster.iipoe.mongodb.net/News?retryWrites=true&w=majority"
);
