<h1>The Indian Express Clone</h1>

_Keep an eye for everything that happens around you_
<!-- <hr> -->

<h3> About </h3>

At Indian Express, we strive to keep you updated with all around the globe. We provide news from all domians of life that can be accessed on the click of a button.  #KeepUpWithTrending 

> In this project we have tried to clone full-stack of indian express. This project is an effort to implement learning at masai and improve our understanding of the web world (React, Express, mongoDB, NodeJs) .  Through this website we are trying to provide with all that happens around you. 
 
<h3> Deployment link </h3>

<a href="https://indianexpress.netlify.app/" target="_blank">https://indianexpress.netlify.app/
 

<hr>
<h3> Tech Stack </h3>
 





<ol>
 <li>HTML</li> 
 <li>CSS</li> 
 <li>Bootstrap</li> 
 <li>JavaScript</li> 
 <li>React</li> 
 <li>NodeJS</li> 
 <li>ExpressJS</li> 
 <li>MongoDB</li> 
</ol>

 <hr>
 
 <h3>Features</h3>
 
 1. One place for all hot and happening.
 2. Subscribe for update that you are intersted in.
 3. Follow all that happpens by minute.

 <hr>
 
  
 
 <h4> Landing Page <h4>
  
  ![5](https://user-images.githubusercontent.com/78145877/175020313-5fe32290-2993-411d-836d-9063c6f98756.png)

  <p>This is the landing page of our best which is high engaging.</P>
  
  <ul>
   <li>Navbar icons will take you to different section of the website</li>
   <li>All trending news can be seen here</li>
   <li>User can login with with google and mobile which is supported by firebase</li>
  </ul>
  
  <h4> India/Sports/Entertainment </h4>
  
  These sections provides you with news related to the perticular domain.
  ![3](https://user-images.githubusercontent.com/78145877/174478599-49a2ea7c-fe13-4c30-b687-29b03390e85f.png)
 ![2](https://user-images.githubusercontent.com/78145877/174478594-e379e731-b4de-4cb6-a0c5-bf36032f63a8.png)
  <h4> Login </h4>
 
  
  > Login cab be done using google, facebook and apple account and is supported by firebase 
  
   ![4](https://user-images.githubusercontent.com/78145877/174478602-70d0274a-5e45-4f86-9aea-129ffb52627e.png)
  
  
 <h3>Contributers </h3>
 <ol>
  
  <li>Tapish Sharma: https://github.com/kakashi10-23 </li>
  
  <li>Aditya Shekhar:  https://github.com/adityasekharbej </li>
   
  <li>Sumit Beniwal: https://github.com/SumitB1412 </li>
   
  <li>Rahul Gupta:  https://github.com/rahulgupta12032003 </li>
   
  <li>Paras Jain: https://github.com/paras0602 </li>
  
 </ol>

